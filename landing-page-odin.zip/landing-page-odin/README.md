# Landing Page (odin)

A Pen created on CodePen.io. Original URL: [https://codepen.io/i-furo/pen/KKrOzdE](https://codepen.io/i-furo/pen/KKrOzdE).

